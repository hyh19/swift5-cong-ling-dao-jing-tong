//
//  Student+CoreDataClass.swift
//  40_CoreDataTest
//
//  Created by 珲少 on 2021/2/9.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
