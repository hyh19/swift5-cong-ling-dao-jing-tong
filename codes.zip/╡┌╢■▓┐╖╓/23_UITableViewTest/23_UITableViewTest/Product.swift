//
//  Product.swift
//  23_UITableViewTest
//
//  Created by 珲少 on 2021/2/7.
//

import UIKit

class Product: NSObject {
    var name:String?
    //表示商品价格
    var price:String?
    //表示商品缩略图
    var imageName:String?
    //表示商品简介
    var subTitle:String?
}
