//
//  _1_SwiftUIDemoApp.swift
//  41_SwiftUIDemo
//
//  Created by 珲少 on 2021/2/11.
//

import SwiftUI

@main
struct SwiftUIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            SimpleView()
        }
    }
}
